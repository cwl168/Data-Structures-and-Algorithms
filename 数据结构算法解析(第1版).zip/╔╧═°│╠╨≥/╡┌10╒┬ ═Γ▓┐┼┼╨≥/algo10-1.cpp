 // algo10-1.cpp
 #define N 32767

 void main()
 {
   int a[N];
 }

