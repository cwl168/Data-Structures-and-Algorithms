 // func5-1.cpp
 int comp(int c1,int c2) 
 { 
   if(c1<c2)
     return -1;
   if(c1==c2)
     return 0;
   return 1;
 }

